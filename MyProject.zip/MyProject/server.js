import contactRoutes
    from "./server/routes/contact.routes.js";

import projectRoutes
    from "./server/routes/project.routes.js";

import qualificationRoutes
    from "./server/routes/qualification.routes.js";

import userRoutes
    from "./server/routes/user.routes.js";

import "dotenv/config";

import app from "./server/express.js";
import router from "./server/assets-router.js";

import authRoutes
    from "./server/routes/auth.routes.js";

import connectDatabase from "./server/config/database.js";


const PORT =
    process.env.PORT || 5000;


// Connect to MongoDB before starting the server
await connectDatabase();


// Existing skeleton route
app.use(
    "/src",
    router
);


// Simple backend test route
app.get(
    "/",
    (req, res) => {

        res.send(
            "Welcome to MyPortfolio backend"
        );

    }
);

app.use(
    "/api/contacts",
    contactRoutes
);


app.use(
    "/api/projects",
    projectRoutes
);


app.use(
    "/api/qualifications",
    qualificationRoutes
);


app.use(
    "/api/users",
    userRoutes
);

app.use(
    "/api/auth",
    authRoutes
);

// Start Express server
app.listen(
    PORT,
    () => {

        console.log(
            `Server running at http://localhost:${PORT}/`
        );

    }
);


export default app;